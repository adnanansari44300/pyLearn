
/* =========================================================
   PYLEARN — INTERACTIVE PYTHON EXERCISE WORKSPACE
   Real Python execution powered by Pyodide
   ========================================================= */

document.addEventListener("DOMContentLoaded", () => {

    /* =====================================================
       ELEMENTS
       ===================================================== */

    const codeEditor = document.getElementById("codeEditor");
    const outputArea = document.getElementById("outputArea");

    const runCodeButton = document.getElementById("runCode");
    const clearOutputButton = document.getElementById("clearOutput");

    const hintButton = document.getElementById("hintButton");
    const solutionButton = document.getElementById("solutionButton");

    const hintCard = document.getElementById("hintCard");
    const solutionCard = document.getElementById("solutionCard");

    const nextExerciseButton =
        document.getElementById("nextExercise");

    const lineNumbers =
        document.querySelector(".line-numbers");


    /* =====================================================
       EXERCISE SETTINGS
       ===================================================== */

    const exerciseId = 1;

    const storageKey =
        `pylearn-exercise-${exerciseId}-code`;

    const defaultCode = `name = "Adnan"
print(name)`;


    /* =====================================================
       PYTHON RUNTIME
       ===================================================== */

    let pyodide = null;
    let pythonReady = false;
    let loadingPython = false;


    /* =====================================================
       LOAD PYODIDE
       ===================================================== */

    async function loadPython() {

        if (pythonReady) {
            return pyodide;
        }

        if (loadingPython) {

            while (!pythonReady) {
                await new Promise(
                    resolve => setTimeout(resolve, 100)
                );
            }

            return pyodide;
        }

        loadingPython = true;

        showOutput(
            "Loading Python runtime...\n\n" +
            "The first load may take a few seconds.",
            "normal"
        );

        try {

            /*
             * Pyodide is loaded directly from its official CDN.
             */

            if (!window.loadPyodide) {

                await new Promise((resolve, reject) => {

                    const script =
                        document.createElement("script");

                    script.src =
                        "https://cdn.jsdelivr.net/pyodide/v0.27.2/full/pyodide.js";

                    script.onload = resolve;

                    script.onerror = () => {
                        reject(
                            new Error(
                                "Unable to load the Python runtime."
                            )
                        );
                    };

                    document.head.appendChild(script);

                });

            }


            pyodide = await window.loadPyodide({

                indexURL:
                    "https://cdn.jsdelivr.net/pyodide/v0.27.2/full/"

            });


            pythonReady = true;

            loadingPython = false;

            showOutput(
                "Python is ready.\n\n" +
                "You can now run real Python code.",
                "success"
            );

            updateRunButton();


            return pyodide;

        }
        catch (error) {

            loadingPython = false;

            console.error(error);

            showOutput(
                "Could not load the Python runtime.\n\n" +
                "Please check your internet connection " +
                "and refresh the page.",
                "error"
            );

            updateRunButton();

            throw error;
        }

    }


    /* =====================================================
       RUN BUTTON STATE
       ===================================================== */

    function updateRunButton() {

        if (!runCodeButton) {
            return;
        }

        if (pythonReady) {

            runCodeButton.disabled = false;

            runCodeButton.innerHTML = `
                <i class="fa-solid fa-play"></i>
                Run Code
            `;

        }
        else if (loadingPython) {

            runCodeButton.disabled = true;

            runCodeButton.innerHTML = `
                <i class="fa-solid fa-spinner fa-spin"></i>
                Loading Python
            `;

        }
        else {

            runCodeButton.disabled = false;

            runCodeButton.innerHTML = `
                <i class="fa-solid fa-play"></i>
                Run Code
            `;

        }

    }


    /* =====================================================
       OUTPUT
       ===================================================== */

    function showOutput(message, type = "normal") {

        if (!outputArea) {
            return;
        }

        outputArea.innerHTML = "";

        const output =
            document.createElement("div");

        if (type === "success") {

            output.className =
                "output-success";

        }
        else if (type === "error") {

            output.className =
                "output-error";

        }
        else {

            output.className =
                "output-normal";

        }

        output.textContent =
            message;

        outputArea.appendChild(output);

    }


    function showRunningMessage() {

        if (!outputArea) {
            return;
        }

        outputArea.innerHTML = `
            <div class="output-normal">
                <i class="fa-solid fa-spinner fa-spin"></i>
                Running Python...
            </div>
        `;

    }


    /* =====================================================
       RUN REAL PYTHON
       ===================================================== */

    async function runPythonCode() {

        if (!codeEditor) {
            return;
        }

        const code =
            codeEditor.value.trim();


        if (!code) {

            showOutput(
                "Please write some Python code first.",
                "error"
            );

            return;
        }


        /* Load Python if necessary */

        if (!pythonReady) {

            try {

                await loadPython();

            }
            catch (error) {

                return;

            }

        }


        showRunningMessage();

        runCodeButton.disabled = true;


        try {

            /*
             * Redirect Python's stdout and stderr
             * into JavaScript strings.
             */

            pyodide.runPython(`
import sys
import io

_pylearn_stdout = io.StringIO()
_pylearn_stderr = io.StringIO()

sys.stdout = _pylearn_stdout
sys.stderr = _pylearn_stderr
            `);


            /*
             * Execute the student's actual Python code.
             */

            await pyodide.runPythonAsync(code);


            /*
             * Retrieve printed output.
             */

            const stdout =
                pyodide.runPython(
                    "_pylearn_stdout.getvalue()"
                );

            const stderr =
                pyodide.runPython(
                    "_pylearn_stderr.getvalue()"
                );


            /*
             * Reset output streams.
             */

            pyodide.runPython(`
sys.stdout = sys.__stdout__
sys.stderr = sys.__stderr__
            `);


            if (stderr && stderr.trim()) {

                showOutput(
                    stderr,
                    "error"
                );

            }
            else if (stdout && stdout.trim()) {

                showOutput(
                    stdout,
                    "success"
                );

            }
            else {

                showOutput(
                    "Code executed successfully.\n\n" +
                    "Your program did not produce any output.",
                    "success"
                );

            }

        }
        catch (error) {

            /*
             * Always restore normal Python output.
             */

            try {

                pyodide.runPython(`
sys.stdout = sys.__stdout__
sys.stderr = sys.__stderr__
                `);

            }
            catch (resetError) {

                console.warn(
                    "Could not reset Python output streams.",
                    resetError
                );

            }


            let errorMessage =
                error.message || String(error);


            /*
             * Remove some unnecessary JavaScript
             * wrapper text from the displayed error.
             */

            errorMessage =
                errorMessage
                    .replace(
                        /^PythonError:\s*/i,
                        ""
                    );


            showOutput(
                errorMessage,
                "error"
            );

        }
        finally {

            runCodeButton.disabled = false;

            updateRunButton();

        }

    }


    /* =====================================================
       RUN CODE BUTTON
       ===================================================== */

    if (runCodeButton) {

        runCodeButton.addEventListener(
            "click",
            runPythonCode
        );

    }


    /* =====================================================
       CLEAR OUTPUT
       ===================================================== */

    if (clearOutputButton) {

        clearOutputButton.addEventListener(
            "click",
            () => {

                outputArea.innerHTML = `
                    <div class="output-placeholder">

                        <i class="fa-solid fa-play"></i>

                        <p>
                            Your program output will appear here.
                        </p>

                        <span>
                            Click <strong>Run Code</strong>
                            to execute your Python program.
                        </span>

                    </div>
                `;

            }
        );

    }


    /* =====================================================
       LINE NUMBERS
       ===================================================== */

    function updateLineNumbers() {

        if (!lineNumbers || !codeEditor) {
            return;
        }

        const lineCount =
            codeEditor.value.split("\n").length;

        lineNumbers.innerHTML = "";

        for (
            let i = 1;
            i <= Math.max(lineCount, 8);
            i++
        ) {

            const span =
                document.createElement("span");

            span.textContent = i;

            lineNumbers.appendChild(span);

        }

    }

    updateLineNumbers();


    if (codeEditor) {

        codeEditor.addEventListener(
            "input",
            updateLineNumbers
        );

    }


    /* =====================================================
       TAB SUPPORT
       ===================================================== */

    if (codeEditor) {

        codeEditor.addEventListener(
            "keydown",
            (event) => {

                if (event.key !== "Tab") {
                    return;
                }

                event.preventDefault();

                const start =
                    codeEditor.selectionStart;

                const end =
                    codeEditor.selectionEnd;

                const value =
                    codeEditor.value;

                codeEditor.value =
                    value.substring(0, start) +
                    "    " +
                    value.substring(end);

                codeEditor.selectionStart =
                    codeEditor.selectionEnd =
                    start + 4;

                updateLineNumbers();

                saveCode();

            }
        );

    }


    /* =====================================================
       CTRL + ENTER
       ===================================================== */

    if (codeEditor) {

        codeEditor.addEventListener(
            "keydown",
            (event) => {

                if (
                    event.ctrlKey &&
                    event.key === "Enter"
                ) {

                    event.preventDefault();

                    runPythonCode();

                }

            }
        );

    }


    /* =====================================================
       HINT
       ===================================================== */

    if (hintButton && hintCard) {

        hintButton.addEventListener(
            "click",
            () => {

                const shouldOpen =
                    hintCard.hidden;

                hintCard.hidden =
                    !shouldOpen;

                if (shouldOpen) {

                    hintCard.scrollIntoView({
                        behavior: "smooth",
                        block: "center"
                    });

                }

            }
        );

    }


    /* =====================================================
       SOLUTION
       ===================================================== */

    if (solutionButton && solutionCard) {

        solutionButton.addEventListener(
            "click",
            () => {

                const shouldOpen =
                    solutionCard.hidden;

                solutionCard.hidden =
                    !shouldOpen;

                if (shouldOpen) {

                    solutionCard.scrollIntoView({
                        behavior: "smooth",
                        block: "center"
                    });

                }

            }
        );

    }


    /* =====================================================
       NEXT EXERCISE
       ===================================================== */

    if (nextExerciseButton) {

        nextExerciseButton.addEventListener(
            "click",
            () => {

                window.location.href =
                    "../practice.html?exercise=2";

            }
        );

    }


    /* =====================================================
       AUTO-SAVE
       ===================================================== */

    function saveCode() {

        if (!codeEditor) {
            return;
        }

        localStorage.setItem(
            storageKey,
            codeEditor.value
        );

    }


    const savedCode =
        localStorage.getItem(storageKey);

    if (savedCode && codeEditor) {

        codeEditor.value =
            savedCode;

    }
    else if (codeEditor) {

        codeEditor.value =
            defaultCode;

    }

    updateLineNumbers();


    if (codeEditor) {

        codeEditor.addEventListener(
            "input",
            saveCode
        );

    }


    /* =====================================================
       INITIALIZE
       ===================================================== */

    updateRunButton();

    /*
     * Start loading Python in the background.
     * The student does not have to click anything first.
     */

    loadPython().catch(() => {
        /*
         * The error is already displayed by loadPython().
         */
    });


    console.log(
        "PyLearn Interactive Python Workspace is ready."
    );

});

