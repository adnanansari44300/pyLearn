/* =========================================================
   PYLEARN
   PROFESSIONAL LESSON JAVASCRIPT
========================================================= */

document.addEventListener("DOMContentLoaded", function () {

    "use strict";


    /* =====================================================
       DARK / LIGHT MODE
    ===================================================== */

    const themeButton =
        document.getElementById("lessonThemeToggle");


    function updateThemeIcon() {

        if (!themeButton) {
            return;
        }

        const icon =
            themeButton.querySelector("i");

        if (!icon) {
            return;
        }

        if (document.body.classList.contains("dark-mode")) {

            icon.className =
                "fa-solid fa-sun";

        } else {

            icon.className =
                "fa-solid fa-moon";

        }

    }


    if (themeButton) {

        themeButton.addEventListener(
            "click",
            function () {

                document.body.classList.toggle(
                    "dark-mode"
                );

                updateThemeIcon();

            }
        );

    }


    updateThemeIcon();


    /* =====================================================
       COPY CODE
    ===================================================== */

    const copyButtons =
        document.querySelectorAll(".copy-code");


    copyButtons.forEach(function (button) {

        button.addEventListener(
            "click",
            async function () {

                const codeCard =
                    button.closest(".code-card");

                if (!codeCard) {
                    return;
                }

                const code =
                    codeCard.querySelector("code");

                if (!code) {
                    return;
                }


                try {

                    await navigator.clipboard.writeText(
                        code.innerText
                    );


                    const original =
                        button.innerHTML;


                    button.innerHTML =
                        '<i class="fa-solid fa-check"></i> Copied';


                    setTimeout(
                        function () {

                            button.innerHTML =
                                original;

                        },
                        1500
                    );

                } catch (error) {

                    button.textContent =
                        "Copy failed";

                }

            }
        );

    });


    /* =====================================================
       TABLE OF CONTENTS
    ===================================================== */

    const tocLinks =
        document.querySelectorAll(
            ".lesson-toc a"
        );


    const sections =
        document.querySelectorAll(
            ".lesson-section"
        );


    function updateTOC() {

        if (
            tocLinks.length === 0 ||
            sections.length === 0
        ) {
            return;
        }


        let currentSection = "";


        sections.forEach(function (section) {

            const top =
                section.getBoundingClientRect().top;


            if (top <= 160) {

                currentSection =
                    section.id;

            }

        });


        tocLinks.forEach(function (link) {

            link.classList.remove("active");


            if (
                link.getAttribute("href") ===
                "#" + currentSection
            ) {

                link.classList.add("active");

            }

        });

    }


    window.addEventListener(
        "scroll",
        updateTOC
    );


    updateTOC();


    /* =====================================================
       SMOOTH SCROLL
    ===================================================== */

    tocLinks.forEach(function (link) {

        link.addEventListener(
            "click",
            function (event) {

                const targetId =
                    link.getAttribute("href");


                if (!targetId) {
                    return;
                }


                const target =
                    document.querySelector(
                        targetId
                    );


                if (!target) {
                    return;
                }


                event.preventDefault();


                target.scrollIntoView({
                    behavior: "smooth",
                    block: "start"
                });

            }
        );

    });


    /* =====================================================
       LESSON READING PROGRESS
    ===================================================== */

    const progressFill =
        document.querySelector(
            ".lesson-progress-fill"
        );


    const progressValue =
        document.querySelector(
            ".lesson-progress-value"
        );


    function updateReadingProgress() {

        if (!progressFill) {
            return;
        }


        const documentHeight =
            document.documentElement.scrollHeight -
            window.innerHeight;


        if (documentHeight <= 0) {
            return;
        }


        const progress =
            Math.min(
                100,
                Math.max(
                    0,
                    (window.scrollY / documentHeight) * 100
                )
            );


        progressFill.style.width =
            progress + "%";


        if (progressValue) {

            progressValue.textContent =
                Math.round(progress) + "%";

        }

    }


    window.addEventListener(
        "scroll",
        updateReadingProgress
    );


    updateReadingProgress();


    /* =====================================================
       QUIZ
    ===================================================== */

    const quizOptions =
        document.querySelectorAll(
            ".quiz-option"
        );


    quizOptions.forEach(function (option) {

        option.addEventListener(
            "click",
            function () {

                const question =
                    option.closest(
                        ".quiz-question"
                    );


                if (!question) {
                    return;
                }


                const options =
                    question.querySelectorAll(
                        ".quiz-option"
                    );


                options.forEach(
                    function (item) {

                        item.classList.remove(
                            "correct",
                            "incorrect"
                        );

                    }
                );


                if (
                    option.dataset.answer ===
                    "correct"
                ) {

                    option.classList.add(
                        "correct"
                    );

                } else {

                    option.classList.add(
                        "incorrect"
                    );


                    const correct =
                        question.querySelector(
                            '[data-answer="correct"]'
                        );


                    if (correct) {

                        correct.classList.add(
                            "correct"
                        );

                    }

                }

            }
        );

    });


    /* =====================================================
       LESSON COMPLETION
    ===================================================== */

    const completeButton =
        document.getElementById(
            "completeLesson"
        );


    const lessonKey =
        "pylearn-lesson-python-introduction";


    if (completeButton) {

        const completed =
            localStorage.getItem(
                lessonKey
            );


        if (completed === "true") {

            completeButton.classList.add(
                "completed"
            );

            completeButton.innerHTML =
                '<i class="fa-solid fa-check"></i> Lesson Completed';

        }


        completeButton.addEventListener(
            "click",
            function () {

                const isCompleted =
                    localStorage.getItem(
                        lessonKey
                    ) === "true";


                if (isCompleted) {

                    localStorage.removeItem(
                        lessonKey
                    );


                    completeButton.classList.remove(
                        "completed"
                    );


                    completeButton.innerHTML =
                        '<i class="fa-solid fa-check"></i> Mark Lesson Complete';

                } else {

                    localStorage.setItem(
                        lessonKey,
                        "true"
                    );


                    completeButton.classList.add(
                        "completed"
                    );


                    completeButton.innerHTML =
                        '<i class="fa-solid fa-check"></i> Lesson Completed';

                }

            }
        );

    }


    /* =====================================================
       KEYBOARD SHORTCUT
    ===================================================== */

    document.addEventListener(
        "keydown",
        function (event) {

            if (
                event.ctrlKey &&
                event.key.toLowerCase() === "k"
            ) {

                event.preventDefault();

                window.location.href =
                    "../index.html";

            }

        }
    );


    console.log(
        "PyLearn lesson system is ready."
    );

});