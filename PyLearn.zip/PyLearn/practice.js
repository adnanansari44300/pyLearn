/* =========================================
   PYLEARN PRACTICE PAGE
========================================= */


/* =========================================
   CONFIGURATION
========================================= */

const PRACTICE_PROGRESS_KEY =
    "pylearn-practice-progress";


const practiceExercises = [

    {
        id: 0,
        title: "Python Variables",
        level: "beginner"
    },

    {
        id: 1,
        title: "Data Types",
        level: "beginner"
    },

    {
        id: 2,
        title: "Operators",
        level: "beginner"
    },

    {
        id: 3,
        title: "Strings",
        level: "beginner"
    },

    {
        id: 4,
        title: "Lists",
        level: "beginner"
    },

    {
        id: 5,
        title: "Dictionaries",
        level: "beginner"
    },

    {
        id: 6,
        title: "Conditions",
        level: "beginner"
    },

    {
        id: 7,
        title: "Loops",
        level: "beginner"
    },

    {
        id: 8,
        title: "Functions",
        level: "intermediate"
    },

    {
        id: 9,
        title: "File Handling",
        level: "intermediate"
    }

];


/* =========================================
   DOM
========================================= */

const cards =
    document.querySelectorAll(
        ".practice-card"
    );


const filters =
    document.querySelectorAll(
        ".filter-button"
    );


const noResults =
    document.getElementById(
        "noPracticeResults"
    );


const startPractice =
    document.getElementById(
        "startPractice"
    );


const finalStartPractice =
    document.getElementById(
        "finalStartPractice"
    );


const themeToggle =
    document.getElementById(
        "practiceThemeToggle"
    );


const mobileMenu =
    document.getElementById(
        "practiceMobileMenu"
    );


const mobileNavigation =
    document.getElementById(
        "practiceMobileNavigation"
    );


/* =========================================
   PROGRESS
========================================= */

function getProgress() {

    try {

        return JSON.parse(
            localStorage.getItem(
                PRACTICE_PROGRESS_KEY
            )
        ) || {};

    } catch {

        return {};

    }

}


function updateStatistics() {

    const progress =
        getProgress();


    let completed = 0;

    let score = 0;


    practiceExercises.forEach(
        exercise => {

            const data =
                progress[exercise.id];

            if (data?.completed) {

                completed++;

                score +=
                    Number(data.score || 100);

            }

        }
    );


    const total =
        practiceExercises.length;


    const percentage =
        total === 0
            ? 0
            : Math.round(
                (completed / total) * 100
            );


    const exerciseCount =
        document.getElementById(
            "exerciseCount"
        );


    const completedCount =
        document.getElementById(
            "completedCount"
        );


    const totalScore =
        document.getElementById(
            "totalScore"
        );


    const practiceProgress =
        document.getElementById(
            "practiceProgress"
        );


    if (exerciseCount) {

        exerciseCount.textContent =
            total;

    }


    if (completedCount) {

        completedCount.textContent =
            completed;

    }


    if (totalScore) {

        totalScore.textContent =
            score;

    }


    if (practiceProgress) {

        practiceProgress.textContent =
            `${percentage}%`;

    }


    updateCardCompletion(
        progress
    );

}


function updateCardCompletion(
    progress
) {

    cards.forEach(card => {

        const id =
            Number(
                card.dataset.exercise
            );


        const completed =
            progress[id]?.completed;


        card.classList.toggle(
            "completed",
            Boolean(completed)
        );


        const button =
            card.querySelector(
                ".practice-start"
            );


        if (
            button &&
            completed
        ) {

            button.innerHTML = `
                Review
                <i class="fa-solid fa-arrow-right"></i>
            `;

        }

    });

}


/* =========================================
   FILTER
========================================= */

function filterExercises(
    selectedLevel
) {

    let visible = 0;


    cards.forEach(card => {

        const level =
            card.dataset.level;


        const shouldShow =
            selectedLevel === "all" ||
            level === selectedLevel;


        card.classList.toggle(
            "hidden",
            !shouldShow
        );


        if (shouldShow) {

            visible++;

        }

    });


    noResults.classList.toggle(
        "visible",
        visible === 0
    );

}


filters.forEach(button => {

    button.addEventListener(
        "click",
        () => {

            filters.forEach(
                item =>
                    item.classList.remove(
                        "active"
                    )
            );


            button.classList.add(
                "active"
            );


            filterExercises(
                button.dataset.filter
            );

        }
    );

});


/* =========================================
   START PRACTICE
========================================= */

function openPractice() {

    /*
     * For now, start with the first
     * exercise.
     *
     * Later this will open the
     * full interactive code editor.
     */

    const firstExercise =
        document.querySelector(
            '.practice-card[data-exercise="0"]'
        );


    if (firstExercise) {

        firstExercise.scrollIntoView({
            behavior: "smooth",
            block: "center"
        });


        firstExercise.style.transform =
            "scale(1.02)";


        setTimeout(
            () => {

                firstExercise.style.transform =
                    "";

            },
            600
        );

    }

}


if (startPractice) {

    startPractice.addEventListener(
        "click",
        openPractice
    );

}


if (finalStartPractice) {

    finalStartPractice.addEventListener(
        "click",
        openPractice
    );

}


/* =========================================
   EXERCISE BUTTONS
========================================= */

document
    .querySelectorAll(
        ".practice-start"
    )
    .forEach(button => {

        button.addEventListener(
            "click",
            event => {

                event.stopPropagation();


                const id =
                    button.dataset.exercise;


                /*
                 * The actual code editor will
                 * be connected here in the
                 * next Practice phase.
                 */

                window.location.href =
                    `practice.html?exercise=${id}`;

            }
        );

    });


/* =========================================
   MOBILE MENU
========================================= */

if (mobileMenu) {

    mobileMenu.addEventListener(
        "click",
        () => {

            mobileNavigation.classList.toggle(
                "visible"
            );


            const isOpen =
                mobileNavigation.classList.contains(
                    "visible"
                );


            mobileMenu.innerHTML =
                isOpen

                    ? '<i class="fa-solid fa-xmark"></i>'

                    : '<i class="fa-solid fa-bars"></i>';

        }
    );

}


/* =========================================
   THEME
========================================= */

function applyTheme(
    theme
) {

    if (
        theme === "dark"
    ) {

        document.body.classList.add(
            "dark-mode"
        );

        themeToggle.innerHTML =
            '<i class="fa-solid fa-sun"></i>';

    } else {

        document.body.classList.remove(
            "dark-mode"
        );

        themeToggle.innerHTML =
            '<i class="fa-solid fa-moon"></i>';

    }

}


if (themeToggle) {

    themeToggle.addEventListener(
        "click",
        () => {

            const dark =
                document.body.classList.toggle(
                    "dark-mode"
                );


            localStorage.setItem(
                "pylearn-practice-theme",
                dark
                    ? "dark"
                    : "light"
            );


            applyTheme(
                dark
                    ? "dark"
                    : "light"
            );

        }
    );

}


/* =========================================
   INITIALIZATION
========================================= */

document.addEventListener(
    "DOMContentLoaded",
    () => {

        updateStatistics();


        const savedTheme =
            localStorage.getItem(
                "pylearn-practice-theme"
            );


        if (savedTheme) {

            applyTheme(
                savedTheme
            );

        }

    }
);