```javascript
/* =========================================================
   PYLEARN
   Python Learning Platform
   Stable JavaScript
========================================================= */

document.addEventListener("DOMContentLoaded", function () {

    "use strict";


    /* =====================================================
       1. DARK / LIGHT MODE
    ===================================================== */

    const themeToggle = document.getElementById("themeToggle");

    function updateThemeIcon() {

        if (!themeToggle) {
            return;
        }

        const icon = themeToggle.querySelector("i");

        if (!icon) {
            return;
        }

        if (document.body.classList.contains("dark-mode")) {

            icon.className = "fa-solid fa-sun";

        } else {

            icon.className = "fa-solid fa-moon";

        }
    }


    if (themeToggle) {

        themeToggle.addEventListener("click", function () {

            document.body.classList.toggle("dark-mode");

            updateThemeIcon();

        });

    }


    updateThemeIcon();


    /* =====================================================
       2. MOBILE MENU
    ===================================================== */

    const mobileMenuButton =
        document.getElementById("mobileMenuButton");

    const mobileNavigation =
        document.getElementById("mobileNavigation");


    if (mobileMenuButton && mobileNavigation) {

        mobileMenuButton.addEventListener("click", function () {

            mobileNavigation.classList.toggle("open");

            const icon =
                mobileMenuButton.querySelector("i");

            if (icon) {

                if (
                    mobileNavigation.classList.contains("open")
                ) {

                    icon.className =
                        "fa-solid fa-xmark";

                } else {

                    icon.className =
                        "fa-solid fa-bars";

                }

            }

        });


        const mobileLinks =
            mobileNavigation.querySelectorAll("a");


        mobileLinks.forEach(function (link) {

            link.addEventListener("click", function () {

                mobileNavigation.classList.remove("open");

                const icon =
                    mobileMenuButton.querySelector("i");

                if (icon) {

                    icon.className =
                        "fa-solid fa-bars";

                }

            });

        });

    }


    /* =====================================================
       3. SEARCH OVERLAY
    ===================================================== */

    const searchButton =
        document.getElementById("searchButton");

    const searchOverlay =
        document.getElementById("searchOverlay");

    const searchClose =
        document.getElementById("searchClose");

    const searchInput =
        document.getElementById("searchInput");

    const searchResults =
        document.getElementById("searchResults");


    function openSearch() {

        if (!searchOverlay) {
            return;
        }

        searchOverlay.classList.add("open");

        if (searchInput) {
            searchInput.focus();
        }

    }


    function closeSearch() {

        if (!searchOverlay) {
            return;
        }

        searchOverlay.classList.remove("open");

    }


    if (searchButton) {

        searchButton.addEventListener(
            "click",
            openSearch
        );

    }


    if (searchClose) {

        searchClose.addEventListener(
            "click",
            closeSearch
        );

    }


    if (searchOverlay) {

        searchOverlay.addEventListener(
            "click",
            function (event) {

                if (event.target === searchOverlay) {

                    closeSearch();

                }

            }
        );

    }


    /* =====================================================
       4. SEARCH LESSONS
    ===================================================== */

    function performSearch() {

        if (!searchInput || !searchResults) {
            return;
        }


        const searchText =
            searchInput.value
                .toLowerCase()
                .trim();


        const lessons =
            document.querySelectorAll(".lesson");


        searchResults.innerHTML = "";


        if (searchText === "") {

            searchResults.innerHTML =
                "<div class='search-result'>" +
                "<strong>Search Python lessons</strong>" +
                "<span>Try variables, loops, functions, lists or classes.</span>" +
                "</div>";

            return;
        }


        let resultsFound = 0;


        lessons.forEach(function (lesson) {

            const lessonText =
                lesson.textContent.toLowerCase();


            if (lessonText.includes(searchText)) {

                resultsFound++;


                const result =
                    document.createElement("div");

                result.className =
                    "search-result";


                const heading =
                    lesson.querySelector(
                        "h3, h4, h5, strong"
                    );


                const title =
                    heading
                        ? heading.textContent.trim()
                        : "Python Lesson";


                result.innerHTML =
                    "<strong>" +
                    title +
                    "</strong>" +
                    "<span>Open this lesson</span>";


                result.addEventListener(
                    "click",
                    function () {

                        closeSearch();

                        lesson.scrollIntoView({
                            behavior: "smooth",
                            block: "start"
                        });

                    }
                );


                searchResults.appendChild(result);

            }

        });


        if (resultsFound === 0) {

            searchResults.innerHTML =
                "<div class='search-result'>" +
                "<strong>No lesson found</strong>" +
                "<span>Try another Python topic.</span>" +
                "</div>";

        }

    }


    if (searchInput) {

        searchInput.addEventListener(
            "input",
            performSearch
        );

    }


    /* =====================================================
       5. KEYBOARD SHORTCUTS
    ===================================================== */

    document.addEventListener(
        "keydown",
        function (event) {

            if (event.key === "Escape") {

                closeSearch();

                if (mobileNavigation) {
                    mobileNavigation.classList.remove("open");
                }

            }


            if (
                event.ctrlKey &&
                event.key.toLowerCase() === "k"
            ) {

                event.preventDefault();

                openSearch();

            }

        }
    );


    /* =====================================================
       6. SMOOTH SCROLLING
    ===================================================== */

    const navigationLinks =
        document.querySelectorAll(
            'a[href^="#"]'
        );


    navigationLinks.forEach(function (link) {

        link.addEventListener(
            "click",
            function (event) {

                const targetId =
                    link.getAttribute("href");


                if (
                    !targetId ||
                    targetId === "#"
                ) {

                    return;

                }


                const target =
                    document.getElementById(
                        targetId.substring(1)
                    );


                if (!target) {
                    return;
                }


                event.preventDefault();


                target.scrollIntoView({
                    behavior: "smooth",
                    block: "start"
                });

            }
        );

    });


    /* =====================================================
       7. LESSON PROGRESS
    ===================================================== */

    const lessons =
        document.querySelectorAll(".lesson");


    const progressBar =
        document.querySelector(".progress-bar");


    const progressNumber =
        document.querySelector(
            ".course-progress strong"
        );


    let completedLessons = [];


    /* Load saved progress */

    try {

        const savedProgress =
            localStorage.getItem(
                "pylearn-progress"
            );


        if (savedProgress) {

            const parsed =
                JSON.parse(savedProgress);


            if (Array.isArray(parsed)) {

                completedLessons = parsed;

            }

        }

    } catch (error) {

        completedLessons = [];

    }


    /* =====================================================
       GET LESSON ID
    ===================================================== */

    function getLessonId(lesson, index) {

        if (lesson.id) {

            return lesson.id;

        }

        return "lesson-" + (index + 1);

    }


    /* =====================================================
       UPDATE PROGRESS
    ===================================================== */

    function updateProgress() {

        if (lessons.length === 0) {

            return;

        }


        let completed = 0;


        lessons.forEach(function (lesson, index) {

            const lessonId =
                getLessonId(
                    lesson,
                    index
                );


            if (
                completedLessons.includes(
                    lessonId
                )
            ) {

                completed++;

            }

        });


        const percentage =
            Math.round(
                (completed / lessons.length) * 100
            );


        if (progressBar) {

            progressBar.style.width =
                percentage + "%";

        }


        if (progressNumber) {

            progressNumber.textContent =
                percentage + "%";

        }

    }


    /* =====================================================
       LESSON BUTTONS
    ===================================================== */

    lessons.forEach(function (lesson, index) {

        const lessonId =
            getLessonId(
                lesson,
                index
            );


        const button =
            lesson.querySelector(
                ".lesson-status"
            );


        if (!button) {

            return;

        }


        /* Restore saved state */

        if (
            completedLessons.includes(
                lessonId
            )
        ) {

            lesson.classList.add("completed");

            button.classList.add("completed");

            button.innerHTML =
                '<i class="fa-solid fa-check"></i> Done';

        }


        /* Click button */

        button.addEventListener(
            "click",
            function (event) {

                event.preventDefault();

                event.stopPropagation();


                const isCompleted =
                    completedLessons.includes(
                        lessonId
                    );


                if (isCompleted) {

                    completedLessons =
                        completedLessons.filter(
                            function (id) {

                                return id !== lessonId;

                            }
                        );


                    lesson.classList.remove(
                        "completed"
                    );


                    button.classList.remove(
                        "completed"
                    );


                    button.textContent =
                        "Complete";


                } else {

                    completedLessons.push(
                        lessonId
                    );


                    lesson.classList.add(
                        "completed"
                    );


                    button.classList.add(
                        "completed"
                    );


                    button.innerHTML =
                        '<i class="fa-solid fa-check"></i> Done';

                }


                try {

                    localStorage.setItem(
                        "pylearn-progress",
                        JSON.stringify(
                            completedLessons
                        )
                    );

                } catch (error) {

                    console.warn(
                        "Progress could not be saved."
                    );

                }


                updateProgress();

            }
        );

    });


    /* Initial progress */

    updateProgress();


    /* =====================================================
       8. ACTIVE NAVIGATION
    ===================================================== */

    const mainNavigation =
        document.querySelector(
            ".main-navigation"
        );


    const sections =
        document.querySelectorAll(
            "section[id]"
        );


    function updateActiveNavigation() {

        if (
            !mainNavigation ||
            sections.length === 0
        ) {

            return;

        }


        const links =
            mainNavigation.querySelectorAll("a");


        let currentSection = "";


        sections.forEach(function (section) {

            const sectionTop =
                section.offsetTop;


            if (
                window.scrollY >=
                sectionTop - 180
            ) {

                currentSection =
                    section.id;

            }

        });


        links.forEach(function (link) {

            link.classList.remove("active");


            const href =
                link.getAttribute("href");


            if (
                href ===
                "#" + currentSection
            ) {

                link.classList.add("active");

            }

        });

    }


    window.addEventListener(
        "scroll",
        updateActiveNavigation
    );


    updateActiveNavigation();


    /* =====================================================
       9. WINDOW RESIZE
    ===================================================== */

    window.addEventListener(
        "resize",
        function () {

            if (
                window.innerWidth > 760 &&
                mobileNavigation
            ) {

                mobileNavigation.classList.remove(
                    "open"
                );


                if (mobileMenuButton) {

                    const icon =
                        mobileMenuButton.querySelector("i");


                    if (icon) {

                        icon.className =
                            "fa-solid fa-bars";

                    }

                }

            }

        }
    );


    /* =====================================================
       PYLEARN READY
    ===================================================== */

    console.log(
        "PyLearn is ready."
    );

});
```
